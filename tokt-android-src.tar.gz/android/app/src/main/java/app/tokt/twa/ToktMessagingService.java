package app.tokt.twa;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

/**
 * Native FCM-mottak. Bakgrunnsmeldinger med notification-payload vises av
 * systemet selv; denne håndterer forgrunnstilfellet og token-rotasjon.
 */
public class ToktMessagingService extends FirebaseMessagingService {

    @Override
    public void onNewToken(String token) {
        getSharedPreferences("tokt", MODE_PRIVATE).edit().putString("fcm", token).apply();
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        String title = "Tokt";
        String body = "";
        if (message.getNotification() != null) {
            if (message.getNotification().getTitle() != null) title = message.getNotification().getTitle();
            if (message.getNotification().getBody() != null) body = message.getNotification().getBody();
        } else if (message.getData().containsKey("body")) {
            body = message.getData().get("body");
            if (message.getData().containsKey("title")) title = message.getData().get("title");
        } else {
            return;
        }

        Intent intent = new Intent(this, TwaLauncherActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            builder = new Notification.Builder(this, "tokt_default");
        } else {
            builder = new Notification.Builder(this);
        }
        builder.setSmallIcon(R.drawable.ic_stat_tokt)
                .setColor(0xFFF97316)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)
                .setContentIntent(pi);

        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.notify((int) (System.currentTimeMillis() % 100000), builder.build());
    }
}
