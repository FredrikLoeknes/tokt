package app.tokt.twa;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.concurrent.TimeUnit;

/**
 * Gjennomsiktig inngangsaktivitet:
 *  1) Ber om varseltillatelse native (Android 13+) - én gang.
 *  2) Henter FCM-token (maks 1,5 sek ventetid) og lagrer det.
 *  3) Starter TWA-en, som sender tokenet videre til nettsiden via ?ntoken=.
 */
public class MainActivity extends Activity {

    private static final int REQ_NOTIF = 71;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences prefs = getSharedPreferences("tokt", MODE_PRIVATE);
        boolean asked = prefs.getBoolean("notif_asked", false);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && !asked) {
            prefs.edit().putBoolean("notif_asked", true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        } else {
            fetchTokenAndLaunch();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        fetchTokenAndLaunch(); // fortsett uansett svar
    }

    private void fetchTokenAndLaunch() {
        final SharedPreferences prefs = getSharedPreferences("tokt", MODE_PRIVATE);
        new Thread(() -> {
            if (prefs.getString("fcm", null) == null) {
                try {
                    String token = Tasks.await(
                            FirebaseMessaging.getInstance().getToken(), 1500, TimeUnit.MILLISECONDS);
                    if (token != null) prefs.edit().putString("fcm", token).apply();
                } catch (Exception ignored) { /* token kommer via onNewToken senere */ }
            }
            runOnUiThread(this::launchTwa);
        }).start();
    }

    private void launchTwa() {
        Intent i = new Intent(this, TwaLauncherActivity.class);
        if (getIntent() != null && getIntent().getData() != null) {
            i.setData(getIntent().getData());
        }
        startActivity(i);
        finish();
    }
}
