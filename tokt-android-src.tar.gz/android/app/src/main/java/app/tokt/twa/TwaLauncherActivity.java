package app.tokt.twa;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.google.android.gms.tasks.Tasks;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.concurrent.TimeUnit;

/**
 * Eneste aktivitet (som i PWABuilder-oppsettet, der launcheren er task root):
 *  1) Ber om varseltillatelse native (Android 13+) - én gang.
 *  2) Henter FCM-token (kort ventetid) og lagrer det.
 *  3) Starter TWA-en via launchTwa(); shouldLaunchImmediately() er false slik
 *     at biblioteket venter på oss (offisielt mønster for asynkron oppstart).
 * Nettsiden får tokenet via ?ntoken= og registrerer det (platform 'android').
 */
public class TwaLauncherActivity extends com.google.androidbrowserhelper.trusted.LauncherActivity {

    private static final int REQ_NOTIF = 71;

    @Override
    protected boolean shouldLaunchImmediately() {
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (isFinishing()) return; // biblioteket avbrøt (f.eks. TWA kjører alt)

        try { createNotificationChannel(); } catch (Exception ignored) {}

        SharedPreferences prefs = getSharedPreferences("tokt", MODE_PRIVATE);
        boolean asked = prefs.getBoolean("notif_asked", false);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                && !asked) {
            prefs.edit().putBoolean("notif_asked", true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        } else {
            fetchTokenThenLaunch();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIF) fetchTokenThenLaunch(); // fortsett uansett svar
    }

    private void fetchTokenThenLaunch() {
        final SharedPreferences prefs = getSharedPreferences("tokt", MODE_PRIVATE);
        new Thread(() -> {
            if (prefs.getString("fcm", null) == null) {
                try {
                    String token = Tasks.await(
                            FirebaseMessaging.getInstance().getToken(), 1500, TimeUnit.MILLISECONDS);
                    if (token != null) prefs.edit().putString("fcm", token).apply();
                } catch (Exception ignored) { /* token kommer via onNewToken senere */ }
            }
            runOnUiThread(() -> { if (!isFinishing()) launchTwa(); });
        }).start();
    }

    @Override
    protected Uri getLaunchingUrl() {
        Uri url = super.getLaunchingUrl();
        String token = getSharedPreferences("tokt", MODE_PRIVATE).getString("fcm", null);
        if (token != null && url.getQueryParameter("ntoken") == null) {
            url = url.buildUpon().appendQueryParameter("ntoken", token).build();
        }
        return url;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    "tokt_default", "Varsler", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Varsler fra Tokt");
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }
}
