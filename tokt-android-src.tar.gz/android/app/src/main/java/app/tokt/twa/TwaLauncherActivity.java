package app.tokt.twa;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

/**
 * TWA-launcher. Utvider androidbrowserhelper sin LauncherActivity med:
 *  - varselkanal for native FCM-varsler
 *  - ?ntoken=<FCM-token> på start-URL-en, så nettsiden kan registrere tokenet
 *    på innlogget bruker (platform 'android').
 */
public class TwaLauncherActivity extends com.google.androidbrowserhelper.trusted.LauncherActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try { createNotificationChannel(); } catch (Exception ignored) {}
    }

    @Override
    protected Uri getLaunchingUrl() {
        Uri url = super.getLaunchingUrl();
        String token = getSharedPreferences("tokt", MODE_PRIVATE).getString("fcm", null);
        if (token != null && url.getQueryParameter("ntoken") == null) {
            url = url.buildUpon().appendQueryParameter("ntoken", token).build();
        }
        return url;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    "tokt_default", "Varsler", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Varsler fra Tokt");
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }
}
